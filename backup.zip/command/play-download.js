const { ytdl } = require('../start/lib/scrape/scrape-ytdl');
const yts = require('yt-search');

module.exports = {
    command: 'play',
    type: ["search"], 
    description: '*Nina - Feast*',
    async execute(client, m, args, NReply) {
        const text = args.join(" ");
        if (!text) return NReply(`what song do you want to play *Example*: .play wide awake`);
        
        let search = await yts(text);
        let videoUrl = search.all[0].url;

        const response = await ytdl(videoUrl);
        const audioUrl = response.data.mp3;

        client.sendMessage(m.chat, { 
            audio: { url: audioUrl },
            mimetype: "audio/mpeg",
            fileName: "audio.mp3",
            contextInfo: {
                forwardingScore: 99999999999,
                isForwarded: true,
                externalAdReply: {
                    showAdAttribution: false,
                    containsAutoReply: true,
                    mediaType: 1,
                    renderLargerThumbnail: true,
                    title: search.all[0].title,
                    body: `Song duration: ${search.all[0].timestamp}`,
                    previewType: "PHOTO",
                    thumbnailUrl: search.all[0].thumbnail
                }
            }
        }, { quoted: m });
    }
};
