const fs = require('fs');

module.exports = {
    command: ['s','sticker'],
    type: ['sticker'],
    description: '*where is the photo?*',
    async execute(client, m, args, NReply) {
        const fatkuns = m?.quoted || m;
        const quoted = (fatkuns?.mtype === 'buttonsMessage') ? fatkuns[Object.keys(fatkuns)[1]] :
                       (fatkuns?.mtype === 'templateMessage') ? fatkuns.hydratedTemplate[Object.keys(fatkuns.hydratedTemplate)[1]] :
                       (fatkuns?.mtype === 'product') ? fatkuns[Object.keys(fatkuns)[0]] :
                       fatkuns;

        const mime = ((quoted?.msg || quoted) || {}).mimetype || '';

        if (!quoted) return NReply('reply image/video with caption .s');

        try {
            if (/image/.test(mime)) {
                const media = await quoted.download();
                const encmedia = await client.sendImageAsSticker(m.chat, media, m, {
                    packname: "N-ꓘiuuR",
                    author: '17Meiii'
                });
            } else if (/video/.test(mime)) {
                if ((quoted?.msg || quoted)?.seconds > 10) {
                    return NReply('maximum 10 seconds for video!');
                }
                const media = await quoted.download();
                const encmedia = await client.sendVideoAsSticker(m.chat, media, m, {
                    packname: "N-ꓘiuuR",
                    author: '17Meiii'
                });
            } else {
                return NReply('Send images/videos with caption .s (video duration 1-10 seconds)');
            }
        } catch (error) {
            console.error(error);
            return NReply('An error occurred while processing the media. Please try again.');
        }
    }
};
