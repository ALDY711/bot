module.exports = {
    command: ['tagall', 'h'],
    type: ['group'],
    description: '*hello everyone*',
    async execute(client, m, args, NReply, isAdmins) {
        if (!isAdmins) return NReply("only admin can use this command");
        if (!m.isGroup) return NReply("This command can only be used in groups");

        const textMessage = args.join(" ") || "kosong";
        let teks = `*👥 Tag All*\n*Pesan : ${textMessage}*\n\n`;

        const groupMetadata = await client.groupMetadata(m.chat);
        const participants = groupMetadata.participants;

        for (let mem of participants) {
            teks += `@${mem.id.split("@")[0]}\n`;
        }

        client.sendMessage(m.chat, {
            text: teks,
            mentions: participants.map((a) => a.id)
        }, { quoted: m });
    }
};
