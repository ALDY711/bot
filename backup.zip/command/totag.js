module.exports = {
    command: ['totag', 'ht'],
    type: ['group'],
    description: '*reply message*',
    async execute(client, m, args, NReply, isAdmins) {
        if (!isAdmins) return NReply("only admin can use this command");
        if (!m.isGroup) return NReply("This command can only be used in groups");
        if (!m.quoted) return NReply(`reply to message with caption .totag`);
        const groupMetadata = await client.groupMetadata(m.chat);
        const participants = groupMetadata.participants;

        client.sendMessage(m.chat, {
            forward: m.quoted.fakeObj,
            mentions: participants.map((a) => a.id)
        }, { quoted: m });
    }
};
