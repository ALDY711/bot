const axios = require("axios");
const fs = require("fs");
const exec = require("child_process").exec;
const { Sticker, StickerTypes } = require("wa-sticker-formatter");
const peler = require('../start/lib/peler')

module.exports = {
    command: 'qc',
    type: ['sticker'],
    description: '*hello world*',
    async execute(client, m, args, NReply) {
        try {
            const dia = (m.quoted?.text ? m.quoted : m).sender;
            const name = await client.getName(dia);
            let teks = m.quoted ? m.quoted.text : args.join(" ") || "";
            const avatar = await client.profilePictureUrl(dia, "image").catch(() => "https://telegra.ph/file/89c1638d9620584e6e140.png");

            if (m.isImage || m.isQuotedImage) {
                let media = await client.downloadAndSaveMediaMessage(m.quoted, getRandomFile('.jpg'));
                let anu = await peler(media);
                const json = {
                    type: "quote",
                    format: "png",
                    backgroundColor: apiColor,
                    width: 512,
                    height: 768,
                    scale: 2,
                    messages: [{
                        entities: [],
                        media: { url: anu },
                        avatar: true,
                        from: {
                            id: pickRandom([0, 4, 5, 3, 2, 7, 5, 9, 8, 1, 6, 10, 9, 7, 5, 3, 1, 2, 4, 6, 8, 0, 10]),
                            name,
                            photo: { url: avatar }
                        },
                        text: teks,
                        replyMessage: {}
                    }]
                };

                const { data } = await axios.post("https://bot.lyo.su/quote/generate", json, {
                    headers: { "Content-Type": "application/json" }
                }).catch(e => e.response || {});

                if (!data.ok) throw data;
                const buffer = Buffer.from(data.result.image, "base64");
                await makeSticker(buffer, client, m);
                fs.unlinkSync(media);

            } else if (m.isQuotedSticker) {
                let media = await client.downloadAndSaveMediaMessage(m.quoted, getRandomFile('.webp'));
                let ran = getRandomFile('.png');
                exec(`ffmpeg -i ${media} ${ran}`, async (err) => {
                    fs.unlinkSync(media);
                    if (err) return NReply(err);
                    let anuah = await peler(ran);
                    const json = {
                        type: "quote",
                        format: "png",
                        backgroundColor: apiColor,
                        width: 512,
                        height: 768,
                        scale: 2,
                        messages: [{
                            entities: [],
                            media: { url: anuah },
                            avatar: true,
                            from: {
                                id: pickRandom([0, 4, 5, 3, 2, 7, 5, 9, 8, 1, 6, 10, 9, 7, 5, 3, 1, 2, 4, 6, 8, 0, 10]),
                                name,
                                photo: { url: avatar }
                            },
                            text: teks,
                            replyMessage: {}
                        }]
                    };

                    const { data } = await axios.post("https://bot.lyo.su/quote/generate", json, {
                        headers: { "Content-Type": "application/json" }
                    }).catch(e => e.response || {});

                    if (!data.ok) throw data;
                    const buffer = Buffer.from(data.result.image, "base64");
                    await makeSticker(buffer, client, m);
                    fs.unlinkSync(ran);
                });
            } else {
                const json = {
                    type: "quote",
                    format: "png",
                    backgroundColor: apiColor,
                    width: 512,
                    height: 768,
                    scale: 2,
                    messages: [{
                        entities: [],
                        avatar: true,
                        from: {
                            id: pickRandom([0, 4, 5, 3, 2, 7, 5, 9, 8, 1, 6, 10, 9, 7, 5, 3, 1, 2, 4, 6, 8, 0, 10]),
                            name,
                            photo: { url: avatar }
                        },
                        text: teks,
                        replyMessage: {}
                    }]
                };

                const { data } = await axios.post("https://bot.lyo.su/quote/generate", json, {
                    headers: { "Content-Type": "application/json" }
                }).catch(e => e.response || {});

                if (!data.ok) NReply(data);
                const buffer = Buffer.from(data.result.image, "base64");
                await makeSticker(buffer, client, m);
            }
        } catch (e) {
            NReply('Sistem error, coba lagi nanti');
            console.log(e);
        }
    }
};

const apiColor = '#232023';

function getRandomFile(ext) {
    return `${Math.floor(Math.random() * 10000)}${ext}`;
}

function pickRandom(arr) {
    return arr[Math.floor(Math.random() * arr.length)];
}

async function makeSticker(media, client, m) {
    const sticker = new Sticker(media, {
        pack: "N-ꓘiuuR",
        author: `17Meiii`,
        type: StickerTypes.FULL, 
        categories: ['🤩', '🎉'], 
        id: '12345',
        quality: 70, 
        background: '#FFFFFF00' 
    });

    const fileName = getRandomFile(".webp");
    const filePath = await sticker.toFile(fileName);
    const stickerBuffer = fs.readFileSync(filePath);

    await client.sendMessage(m.chat, {
        sticker: stickerBuffer,
        contextInfo: {
            externalAdReply: {
                showAdAttribution: true,
                title: `Takina Assistant`, 
                mediaType: 3,
                renderLargerThumbnail: true,
                thumbnailUrl: `KTech`,
                sourceUrl: `https://wa.me/6281351692548`
            }
        }
    }, { quoted: m });

    fs.unlinkSync(filePath); 
}
