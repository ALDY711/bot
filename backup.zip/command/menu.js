const fs = require('fs');
const path = require('path');

const pluginsDir = __dirname;

const getPlugins = () => {
    const plugins = fs.readdirSync(pluginsDir); 
    const commands = {};

    plugins.forEach((file) => {
        if (file.endsWith('.js') && file !== 'menu.js') { 
            const plugin = require(path.join(pluginsDir, file)); 
            if (plugin.command && plugin.type) { 
                const commandArray = Array.isArray(plugin.command) ? plugin.command : [plugin.command];
                plugin.type.forEach((type) => {
                    if (!commands[type]) commands[type] = []; 
                    commandArray.forEach((cmd) => {
                        commands[type].push({
                            command: cmd,
                            description: plugin.description || 'No description available'
                        });
                    });
                });
            }
        }
    });

    return commands;
};

const displayMenu = (client, commands) => {
    let menuText = `*Takina Assistant* is a WhatsApp bot built with NodeJS and the Baileys library, designed to enhance user interaction on the platform.\n\n`;
    
    menuText += `  ▢ Creator : ALDY\n`;
    menuText += `  ▢ Library : WS-Baileys\n`;
    menuText += `  ▢ Mode : ${client.public ? 'public' : 'self'}\n`; 
    menuText += `  ▢ Type : Plugin\n\n`;

    for (const [type, cmdList] of Object.entries(commands)) {
        menuText += `— ${type}\n`;
        cmdList.forEach(cmd => {
            menuText += `𐓷 .${cmd.command} ${cmd.description}\n`;
        });
        menuText += '\n'; 
    }

    menuText += `Takina Assistant is an innovative WhatsApp bot that enhances interaction through games and AI features to assist users with tasks.\n`;

    return menuText;
};

module.exports = {
    command: 'menu',
    type: ["main"],
    async execute(client, m, args, pushName) {
        const commands = getPlugins(); 
        const menuText = displayMenu(client, commands); 
        menu(menuText); 
    }
};
